#README

How to : 

1. Download and extract the files.
2. Install Vash ( npm install --save vash)
3. run : npm start
